# Team NASDAS — Générateur de vlog

Application Streamlit qui assemble des photos des membres et de la villa en une vidéo MP4 verticale (TikTok / Instagram Reels), avec phrases personnalisées, voix française automatique facultative et musique facultative.

## Contenu
- `app.py` : interface Streamlit.
- `generator.py` : génération du montage vidéo et des voix.
- `requirements.txt` : dépendances Python.

## Installation

Python 3.10 ou 3.11 recommandé.

### Windows
```bash
py -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
streamlit run app.py
```

### macOS / Linux
```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
streamlit run app.py
```

Ouvre ensuite l'adresse locale affichée par Streamlit, généralement `http://localhost:8501`.

## Utilisation
1. Ajoute une photo pour chaque membre que tu veux afficher.
2. Modifie les phrases si nécessaire.
3. Ajoute une ou plusieurs photos de la villa.
4. Facultatif : ajoute une musique dont tu possèdes les droits.
5. Choisis la voix, le format et la qualité dans la barre latérale.
6. Clique sur **GÉNÉRER LA VIDÉO**, puis télécharge le MP4.

## Voix automatique
La synthèse vocale utilise Edge TTS et nécessite une connexion Internet au moment de la génération. Si le service vocal est indisponible, le montage peut être créé sans voix en décochant l'option correspondante.

## Déploiement
Pour un déploiement sur Streamlit Community Cloud :
1. Dépose les trois fichiers du projet dans un dépôt GitHub.
2. Dans Streamlit Community Cloud, crée une application à partir de ce dépôt.
3. Sélectionne `app.py` comme fichier principal.
4. Déploie.

La génération vidéo peut consommer beaucoup de mémoire et de temps CPU. Pour des vidéos plus longues ou une utilisation régulière, privilégie un serveur avec FFmpeg disponible et des ressources suffisantes.

## Notes
- Les photos doivent être au format JPG, JPEG, PNG ou WEBP.
- Les vidéos sont exportées en MP4 H.264 avec audio AAC.
- Le format vertical est 1080 × 1920 ; le format carré est 1080 × 1080.
- Utilise uniquement des photos, voix et musiques pour lesquelles tu disposes des autorisations nécessaires.
